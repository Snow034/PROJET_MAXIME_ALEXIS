<?php
require_once "../includes/config.php";
require_once "../includes/functions.php";
checkAdmin(); // sécurise la page

// Gestion articles et utilisateurs ici (CRUD + changement rôle)
// Même logique que précédemment mais protégée par checkAdmin()
?>
