<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

try{
    $pdo = new PDO(
        "mysql:host=sql100.infinityfree.com;port=3306;dbname=if0_40940109_bdd;charset=utf8",
        "if0_40940109",
        "oSplGzwp7ACsL",
        [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]
    );
    echo "Connexion réussie !";
}catch(PDOException $e){
    echo "Erreur BDD : ".$e->getMessage();
}
