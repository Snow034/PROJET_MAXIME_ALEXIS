<?php
require_once "includes/config.php";

// INSCRIPTION
if(isset($_POST['register'])){
    $username = $_POST['username'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    if($username && $email && $password){
        $hash = password_hash($password,PASSWORD_DEFAULT);
        $pdo->prepare("INSERT INTO user (username,email,password,role) VALUES (?,?,?,'user')")
            ->execute([$username,$email,$hash]);
        log_msg("Nouvel utilisateur créé : $username / $email");
    }
}

// CONNEXION
if(isset($_POST['login'])){
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    if($email && $password){
        $stmt = $pdo->prepare("SELECT * FROM user WHERE email=?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if($user && password_verify($password,$user['password'])){
            $_SESSION['user_id']=$user['id'];
            $_SESSION['username']=$user['username'];
            $_SESSION['role']=$user['role'];
            header("Location:/index.php");
            exit;
        } else {
            $error="Email ou mot de passe incorrect";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Connexion</title></head>
<body>
<h1>Connexion / Inscription</h1>
<?php if(isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
<h2>Inscription</h2>
<form method="post">
Username: <input name="username" required><br>
Email: <input name="email" required><br>
Password: <input type="password" name="password" required><br>
<button name="register">Créer compte</button>
</form>

<h2>Connexion</h2>
<form method="post">
Email: <input name="email" required><br>
Password: <input type="password" name="password" required><br>
<button name="login">Connexion</button>
</form>
</body>
</html>
