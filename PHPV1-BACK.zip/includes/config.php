<?php
// Vérification admin
function checkAdmin(){
    if(!isset($_SESSION['role']) || $_SESSION['role']!=='admin'){
        $_SESSION['error'] = "Vous n'avez pas la permission pour cette action.";
        header("Location:/index.php");
        exit;
    }
}

// Upload image sécurisé
function uploadImage($file){
    global $LOGS;
    if($file && isset($file['error']) && $file['error']===0){
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $name = uniqid().".".$ext;
        if(move_uploaded_file($file['tmp_name'], __DIR__."/../uploads/".$name)){
            $LOGS[] = "[".date("Y-m-d H:i:s")."] Image uploadée : ".$name;
            return "uploads/".$name;
        }
    }
    return null;
}
