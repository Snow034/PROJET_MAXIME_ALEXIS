<?php
require_once __DIR__ . "/includes/config.php";
require_once __DIR__ . "/includes/functions.php";

$is_logged_in = isset($_SESSION['user_id']);

// Récupérer l'ID du profil à afficher
$profile_id = isset($_GET['id']) ? intval($_GET['id']) : ($is_logged_in ? $_SESSION['user_id'] : 0);

if ($profile_id <= 0) {
    header("Location: /index.php");
    exit;
}

$error = '';
$success = '';
$is_own_profile = $is_logged_in && $profile_id == $_SESSION['user_id'];

// Récupérer les informations de l'utilisateur
try {
    $stmt = $pdo->prepare("SELECT id, username, email, bio, created_at FROM user WHERE id = ?");
    $stmt->execute([$profile_id]);
    $user = $stmt->fetch();
    
    if (!$user) {
        header("Location: /index.php");
        exit;
    }
} catch (PDOException $e) {
    log_msg("Erreur récupération profil : " . $e->getMessage());
    header("Location: /index.php");
    exit;
}

// Mise à jour du profil
if (isset($_POST['update_profile']) && $is_own_profile) {
    $new_bio = isset($_POST['bio']) ? trim($_POST['bio']) : '';
    
    try {
        $stmt = $pdo->prepare("UPDATE user SET bio = ? WHERE id = ?");
        $stmt->execute([$new_bio, $profile_id]);
        $success = "Profil mis à jour avec succès !";
        $user['bio'] = $new_bio;
        log_msg("Profil mis à jour par " . $_SESSION['username']);
    } catch (PDOException $e) {
        $error = "Erreur lors de la mise à jour.";
        log_msg("Erreur mise à jour profil : " . $e->getMessage());
    }
}

// Récupérer les statistiques
$stats = [
    'articles_count' => 0,
    'comments_count' => 0,
    'likes_count' => 0
];

try {
    // Nombre d'articles écrits
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM articles WHERE author_id = ?");
    $stmt->execute([$profile_id]);
    $stats['articles_count'] = $stmt->fetch()['count'];
    
    // Nombre de commentaires
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM comments WHERE user_id = ?");
    $stmt->execute([$profile_id]);
    $stats['comments_count'] = $stmt->fetch()['count'];
    
    // Nombre de likes donnés
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM likes WHERE user_id = ?");
    $stmt->execute([$profile_id]);
    $stats['likes_count'] = $stmt->fetch()['count'];
} catch (PDOException $e) {
    log_msg("Erreur récupération stats : " . $e->getMessage());
}

// Récupérer les articles aimés
$liked_articles = [];
try {
    $stmt = $pdo->prepare("
        SELECT a.*, u.username, l.created_at as liked_at 
        FROM likes l 
        JOIN articles a ON l.article_id = a.id 
        LEFT JOIN user u ON a.author_id = u.id 
        WHERE l.user_id = ? 
        ORDER BY l.created_at DESC
    ");
    $stmt->execute([$profile_id]);
    $liked_articles = $stmt->fetchAll();
} catch (PDOException $e) {
    log_msg("Erreur récupération articles aimés : " . $e->getMessage());
}

// Récupérer les commentaires récents
$recent_comments = [];
try {
    $stmt = $pdo->prepare("
        SELECT c.*, a.title as article_title, a.id as article_id 
        FROM comments c 
        JOIN articles a ON c.article_id = a.id 
        WHERE c.user_id = ? 
        ORDER BY c.created_at DESC 
        LIMIT 10
    ");
    $stmt->execute([$profile_id]);
    $recent_comments = $stmt->fetchAll();
} catch (PDOException $e) {
    log_msg("Erreur récupération commentaires : " . $e->getMessage());
}

// Récupérer les articles écrits (si c'est un auteur)
$written_articles = [];
if ($stats['articles_count'] > 0) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM articles WHERE author_id = ? ORDER BY created_at DESC");
        $stmt->execute([$profile_id]);
        $written_articles = $stmt->fetchAll();
    } catch (PDOException $e) {
        log_msg("Erreur récupération articles écrits : " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil de <?php echo htmlspecialchars($user['username']); ?></title>
</head>
<body>
    <p><a href="/index.php">← Retour à l'accueil</a></p>

    <?php if ($error): ?>
        <p style="color:red;"><?php echo htmlspecialchars($error); ?></p>
    <?php endif; ?>
    
    <?php if ($success): ?>
        <p style="color:green;"><?php echo htmlspecialchars($success); ?></p>
    <?php endif; ?>

    <div style="border:1px solid #ddd; padding:20px; margin-bottom:20px;">
        <h1><?php echo htmlspecialchars($user['username']); ?></h1>
        <?php if ($is_own_profile): ?>
            <p><small>Email: <?php echo htmlspecialchars($user['email']); ?></small></p>
        <?php endif; ?>
        <p><small>Membre depuis le <?php echo date('d/m/Y', strtotime($user['created_at'])); ?></small></p>
        
        <hr>
        
        <h3>Biographie</h3>
        <?php if ($is_own_profile): ?>
            <form method="post">
                <textarea name="bio" style="width:100%; height:100px;"><?php echo htmlspecialchars($user['bio'] ?? ''); ?></textarea><br><br>
                <button type="submit" name="update_profile">Mettre à jour ma bio</button>
            </form>
        <?php else: ?>
            <p><?php echo $user['bio'] ? nl2br(htmlspecialchars($user['bio'])) : '<em>Aucune biographie</em>'; ?></p>
        <?php endif; ?>
    </div>

    <div style="border:1px solid #ddd; padding:20px; margin-bottom:20px;">
        <h2>Statistiques</h2>
        <p><strong>Articles écrits :</strong> <?php echo $stats['articles_count']; ?></p>
        <p><strong>Commentaires :</strong> <?php echo $stats['comments_count']; ?></p>
        <p><strong>Articles aimés :</strong> <?php echo $stats['likes_count']; ?></p>
    </div>

    <?php if (!empty($written_articles)): ?>
        <h2>Articles écrits par <?php echo htmlspecialchars($user['username']); ?> (<?php echo count($written_articles); ?>)</h2>
        <?php foreach ($written_articles as $article): ?>
            <div style="border:1px solid #ddd; padding:15px; margin-bottom:10px;">
                <h3><a href="/article.php?id=<?php echo $article['id']; ?>"><?php echo htmlspecialchars($article['title']); ?></a></h3>
                <p><small><?php echo date('d/m/Y à H:i', strtotime($article['created_at'])); ?></small></p>
                <p><?php echo nl2br(htmlspecialchars(substr($article['content'], 0, 150))); ?>...</p>
            </div>
        <?php endforeach; ?>
        <hr>
    <?php endif; ?>

    <?php if (!empty($liked_articles)): ?>
        <h2>Articles aimés (<?php echo count($liked_articles); ?>)</h2>
        <?php foreach ($liked_articles as $article): ?>
            <div style="border:1px solid #ddd; padding:15px; margin-bottom:10px; background:#f9f9f9;">
                <h3><a href="/article.php?id=<?php echo $article['id']; ?>"><?php echo htmlspecialchars($article['title']); ?></a></h3>
                <p>
                    <small>
                        Par <a href="/profile.php?id=<?php echo $article['author_id']; ?>"><?php echo htmlspecialchars($article['username']); ?></a> • 
                        Aimé le <?php echo date('d/m/Y', strtotime($article['liked_at'])); ?>
                    </small>
                </p>
            </div>
        <?php endforeach; ?>
        <hr>
    <?php endif; ?>

    <?php if (!empty($recent_comments)): ?>
        <h2>Commentaires récents (<?php echo count($recent_comments); ?>)</h2>
        <?php foreach ($recent_comments as $comment): ?>
            <div style="border:1px solid #ddd; padding:15px; margin-bottom:10px; background:#f0f0f0;">
                <p>
                    Sur l'article: <a href="/article.php?id=<?php echo $comment['article_id']; ?>"><strong><?php echo htmlspecialchars($comment['article_title']); ?></strong></a>
                </p>
                <p><?php echo nl2br(htmlspecialchars($comment['comment'])); ?></p>
                <p><small><?php echo date('d/m/Y à H:i', strtotime($comment['created_at'])); ?></small></p>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <?php if (empty($liked_articles) && empty($recent_comments) && empty($written_articles)): ?>
        <p><em>Aucune activité pour le moment.</em></p>
    <?php endif; ?>
</body>
</html>