<?php
require_once __DIR__ . "/includes/config.php";
require_once __DIR__ . "/includes/functions.php";

$is_logged_in = isset($_SESSION['user_id']);

// Récupérer l'ID de l'article
$article_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($article_id <= 0) {
    header("Location: /index.php");
    exit;
}

$error = '';
$success = '';

// Récupérer l'article
try {
    $stmt = $pdo->prepare("SELECT a.*, u.username FROM articles a LEFT JOIN user u ON a.author_id = u.id WHERE a.id = ?");
    $stmt->execute([$article_id]);
    $article = $stmt->fetch();
    
    if (!$article) {
        header("Location: /index.php");
        exit;
    }
} catch (PDOException $e) {
    log_msg("Erreur récupération article : " . $e->getMessage());
    header("Location: /index.php");
    exit;
}

// Compter les likes
$likes_count = 0;
$user_liked = false;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM likes WHERE article_id = ?");
    $stmt->execute([$article_id]);
    $likes_count = $stmt->fetch()['count'];
    
    if ($is_logged_in) {
        $stmt = $pdo->prepare("SELECT id FROM likes WHERE article_id = ? AND user_id = ?");
        $stmt->execute([$article_id, $_SESSION['user_id']]);
        $user_liked = $stmt->fetch() ? true : false;
    }
} catch (PDOException $e) {
    log_msg("Erreur comptage likes : " . $e->getMessage());
}

// Gérer le like/unlike
if (isset($_POST['toggle_like']) && $is_logged_in) {
    try {
        if ($user_liked) {
            // Unlike
            $stmt = $pdo->prepare("DELETE FROM likes WHERE article_id = ? AND user_id = ?");
            $stmt->execute([$article_id, $_SESSION['user_id']]);
            log_msg("Article '" . $article['title'] . "' unliké par " . $_SESSION['username']);
        } else {
            // Like
            $stmt = $pdo->prepare("INSERT INTO likes (article_id, user_id) VALUES (?, ?)");
            $stmt->execute([$article_id, $_SESSION['user_id']]);
            log_msg("Article '" . $article['title'] . "' liké par " . $_SESSION['username']);
        }
        header("Location: article.php?id=" . $article_id);
        exit;
    } catch (PDOException $e) {
        $error = "Erreur lors de l'action.";
        log_msg("Erreur toggle like : " . $e->getMessage());
    }
}

// Ajouter un commentaire
if (isset($_POST['add_comment']) && $is_logged_in) {
    $comment = isset($_POST['comment']) ? trim($_POST['comment']) : '';
    
    if (empty($comment)) {
        $error = "Le commentaire ne peut pas être vide.";
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO comments (article_id, user_id, comment, created_at) VALUES (?, ?, ?, NOW())");
            $stmt->execute([$article_id, $_SESSION['user_id'], $comment]);
            $success = "Commentaire ajouté avec succès !";
            log_msg("Commentaire ajouté sur '" . $article['title'] . "' par " . $_SESSION['username']);
            header("Location: article.php?id=" . $article_id);
            exit;
        } catch (PDOException $e) {
            $error = "Erreur lors de l'ajout du commentaire.";
            log_msg("Erreur ajout commentaire : " . $e->getMessage());
        }
    }
}

// Supprimer un commentaire
if (isset($_GET['delete_comment']) && $is_logged_in) {
    $comment_id = intval($_GET['delete_comment']);
    try {
        // Vérifier que le commentaire appartient à l'utilisateur ou qu'il est admin
        $stmt = $pdo->prepare("SELECT user_id FROM comments WHERE id = ?");
        $stmt->execute([$comment_id]);
        $comment = $stmt->fetch();
        
        if ($comment && ($comment['user_id'] == $_SESSION['user_id'] || $_SESSION['role'] === 'admin')) {
            $stmt = $pdo->prepare("DELETE FROM comments WHERE id = ?");
            $stmt->execute([$comment_id]);
            $success = "Commentaire supprimé.";
            log_msg("Commentaire supprimé sur '" . $article['title'] . "' par " . $_SESSION['username']);
        }
        header("Location: article.php?id=" . $article_id);
        exit;
    } catch (PDOException $e) {
        $error = "Erreur lors de la suppression.";
        log_msg("Erreur suppression commentaire : " . $e->getMessage());
    }
}

// Récupérer les commentaires
$comments = [];
try {
    $stmt = $pdo->prepare("SELECT c.*, u.username FROM comments c LEFT JOIN user u ON c.user_id = u.id WHERE c.article_id = ? ORDER BY c.created_at DESC");
    $stmt->execute([$article_id]);
    $comments = $stmt->fetchAll();
} catch (PDOException $e) {
    log_msg("Erreur récupération commentaires : " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($article['title']); ?> - Blog</title>
</head>
<body>
    <p><a href="/index.php">← Retour aux articles</a></p>

    <?php if ($error): ?>
        <p style="color:red;"><?php echo htmlspecialchars($error); ?></p>
    <?php endif; ?>
    
    <?php if ($success): ?>
        <p style="color:green;"><?php echo htmlspecialchars($success); ?></p>
    <?php endif; ?>

    <article style="border:1px solid #ddd; padding:20px; margin-bottom:20px;">
        <?php if ($article['image']): ?>
            <img src="/<?php echo htmlspecialchars($article['image']); ?>" 
                 alt="<?php echo htmlspecialchars($article['title']); ?>" 
                 style="max-width:100%; height:auto;">
        <?php endif; ?>
        
        <h1><?php echo htmlspecialchars($article['title']); ?></h1>
        
        <p>
            <small>
                Par <a href="/profile.php?id=<?php echo $article['author_id']; ?>"><?php echo htmlspecialchars($article['username'] ?? 'Inconnu'); ?></a> • 
                <?php echo date('d/m/Y à H:i', strtotime($article['created_at'])); ?>
            </small>
        </p>
        
        <hr>
        
        <div><?php echo nl2br(htmlspecialchars($article['content'])); ?></div>
        
        <hr>
        
        <div>
            <strong><?php echo $likes_count; ?> J'aime</strong>
            
            <?php if ($is_logged_in): ?>
                <form method="post" style="display:inline;">
                    <button type="submit" name="toggle_like">
                        <?php echo $user_liked ? '❤️ Je n\'aime plus' : '🤍 J\'aime'; ?>
                    </button>
                </form>
            <?php else: ?>
                <p><em><a href="/login.php">Connectez-vous</a> pour aimer cet article</em></p>
            <?php endif; ?>
        </div>
    </article>

    <hr>

    <h2>Commentaires (<?php echo count($comments); ?>)</h2>

    <?php if ($is_logged_in): ?>
        <form method="post" style="border:1px solid #ddd; padding:15px; margin-bottom:20px;">
            <label><strong>Ajouter un commentaire :</strong></label><br>
            <textarea name="comment" required style="width:100%; height:80px;" placeholder="Votre commentaire..."></textarea><br><br>
            <button type="submit" name="add_comment">Publier le commentaire</button>
        </form>
    <?php else: ?>
        <p><em><a href="/login.php">Connectez-vous</a> pour commenter cet article</em></p>
    <?php endif; ?>

    <?php if (empty($comments)): ?>
        <p>Aucun commentaire pour le moment. Soyez le premier à commenter !</p>
    <?php else: ?>
        <?php foreach ($comments as $comment): ?>
            <div style="border:1px solid #ddd; padding:15px; margin-bottom:10px; background:#f9f9f9;">
                <p>
                    <strong><a href="/profile.php?id=<?php echo $comment['user_id']; ?>"><?php echo htmlspecialchars($comment['username']); ?></a></strong> • 
                    <small><?php echo date('d/m/Y à H:i', strtotime($comment['created_at'])); ?></small>
                </p>
                <p><?php echo nl2br(htmlspecialchars($comment['comment'])); ?></p>
                
                <?php if ($is_logged_in && ($comment['user_id'] == $_SESSION['user_id'] || $_SESSION['role'] === 'admin')): ?>
                    <a href="?id=<?php echo $article_id; ?>&delete_comment=<?php echo $comment['id']; ?>" 
                       onclick="return confirm('Supprimer ce commentaire ?');">
                        Supprimer
                    </a>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</body>
</html>