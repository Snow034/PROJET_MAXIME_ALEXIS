<?php
require_once __DIR__ . "/../includes/config.php";
require_once __DIR__ . "/../includes/functions.php";

checkAdmin();

// Chemin du fichier de logs
$log_file = __DIR__ . "/../logs/app.log";

// Lire les logs (dernières 100 lignes)
$logs = [];
if (file_exists($log_file) && is_readable($log_file)) {
    $lines = file($log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $logs = array_reverse(array_slice($lines, -100)); // 100 dernières lignes, inversées
}

// API pour récupérer les logs en JSON (pour le rafraîchissement AJAX)
if (isset($_GET['api']) && $_GET['api'] === 'get_logs') {
    header('Content-Type: application/json');
    echo json_encode(['logs' => $logs, 'count' => count($logs)]);
    exit;
}

// Vider les logs
if (isset($_POST['clear_logs'])) {
    if (file_exists($log_file) && is_writable($log_file)) {
        file_put_contents($log_file, '');
        log_msg("Logs vidés par " . $_SESSION['username']);
        header("Location: logs.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logs système</title>
</head>
<body>
    <h1>Logs système</h1>
    <p><a href="dashboard.php">← Retour au dashboard</a></p>

    <p>
        <button onclick="toggleLogs()" id="toggleBtn">Afficher les logs</button>
        <button onclick="refreshLogs()">Rafraîchir manuellement</button>
        
        <label>
            <input type="checkbox" id="autoRefresh" onchange="toggleAutoRefresh()" checked>
            Rafraîchissement automatique (toutes les 3 secondes)
        </label>
        
        <form method="post" style="display:inline;" onsubmit="return confirm('Êtes-vous sûr de vouloir vider tous les logs ?');">
            <button type="submit" name="clear_logs">Vider les logs</button>
        </form>
    </p>

    <div id="logsContainer" style="display:none;">
        <p>Total: <strong id="logsCount"><?php echo count($logs); ?></strong> entrées</p>
        
        <div id="logsContent" style="background:#f4f4f4; border:1px solid #ddd; padding:10px; max-height:600px; overflow-y:auto; font-family:monospace; font-size:13px;">
            <?php if (empty($logs)): ?>
                <p>Aucun log disponible.</p>
            <?php else: ?>
                <?php foreach ($logs as $log): ?>
                    <div style="border-bottom:1px solid #ddd; padding:5px 0;">
                        <?php echo htmlspecialchars($log); ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <script>
        let autoRefreshInterval = null;
        let isVisible = false;

        // Afficher/cacher les logs
        function toggleLogs() {
            const container = document.getElementById('logsContainer');
            const btn = document.getElementById('toggleBtn');
            
            isVisible = !isVisible;
            
            if (isVisible) {
                container.style.display = 'block';
                btn.textContent = 'Masquer les logs';
            } else {
                container.style.display = 'none';
                btn.textContent = 'Afficher les logs';
            }
        }

        // Rafraîchir les logs via AJAX
        function refreshLogs() {
            fetch('logs.php?api=get_logs')
                .then(response => response.json())
                .then(data => {
                    const logsContent = document.getElementById('logsContent');
                    const logsCount = document.getElementById('logsCount');
                    
                    logsCount.textContent = data.count;
                    
                    if (data.logs.length === 0) {
                        logsContent.innerHTML = '<p>Aucun log disponible.</p>';
                    } else {
                        logsContent.innerHTML = data.logs.map(log => 
                            `<div style="border-bottom:1px solid #ddd; padding:5px 0;">${escapeHtml(log)}</div>`
                        ).join('');
                    }
                })
                .catch(error => {
                    console.error('Erreur lors du rafraîchissement des logs:', error);
                });
        }

        // Activer/désactiver le rafraîchissement automatique
        function toggleAutoRefresh() {
            const checkbox = document.getElementById('autoRefresh');
            
            if (checkbox.checked) {
                // Démarrer le rafraîchissement automatique toutes les 3 secondes
                autoRefreshInterval = setInterval(refreshLogs, 3000);
            } else {
                // Arrêter le rafraîchissement automatique
                if (autoRefreshInterval) {
                    clearInterval(autoRefreshInterval);
                    autoRefreshInterval = null;
                }
            }
        }

        // Échapper le HTML pour éviter les injections XSS
        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        // Démarrer le rafraîchissement automatique au chargement
        toggleAutoRefresh();
    </script>
</body>
</html>