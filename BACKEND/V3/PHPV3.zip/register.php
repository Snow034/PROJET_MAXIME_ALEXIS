<?php
require_once __DIR__ . "/includes/config.php";
require_once __DIR__ . "/includes/functions.php";

$error = '';
$success = '';

// INSCRIPTION
if (isset($_POST['register'])) {
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    $confirm_password = isset($_POST['confirm_password']) ? trim($_POST['confirm_password']) : '';
    $bio = isset($_POST['bio']) ? trim($_POST['bio']) : '';
    
    if (empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
        $error = "Tous les champs obligatoires sont requis.";
    } elseif (!is_valid_email($email)) {
        $error = "Email invalide.";
    } elseif (strlen($password) < 6) {
        $error = "Le mot de passe doit contenir au moins 6 caractères.";
    } elseif (strlen($username) < 3) {
        $error = "Le nom d'utilisateur doit contenir au moins 3 caractères.";
    } elseif ($password !== $confirm_password) {
        $error = "Les mots de passe ne correspondent pas.";
    } else {
        try {
            // Vérifier si l'email existe déjà
            $stmt = $pdo->prepare("SELECT id FROM user WHERE email = ?");
            $stmt->execute([$email]);
            
            if ($stmt->fetch()) {
                $error = "Cet email est déjà utilisé.";
            } else {
                // Vérifier si le username existe déjà
                $stmt = $pdo->prepare("SELECT id FROM user WHERE username = ?");
                $stmt->execute([$username]);
                
                if ($stmt->fetch()) {
                    $error = "Ce nom d'utilisateur est déjà pris.";
                } else {
                    // Créer le compte
                    $hash = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("INSERT INTO user (username, email, password, bio, role) VALUES (?, ?, ?, ?, 'user')");
                    $stmt->execute([$username, $email, $hash, $bio]);
                    
                    log_msg("Nouvel utilisateur créé : $username / $email");
                    $success = "Compte créé avec succès ! Vous pouvez maintenant vous connecter.";
                }
            }
        } catch (PDOException $e) {
            $error = "Erreur lors de la création du compte.";
            log_msg("Erreur inscription : " . $e->getMessage());
        }
    }
}

// Si déjà connecté, rediriger
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] === 'admin') {
        redirect('/admin/dashboard.php');
    } else {
        redirect('/index.php');
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Créer un compte</title>
</head>
<body>
    <h1>Créer un compte</h1>
    
    <p><a href="/index.php">← Retour à l'accueil</a></p>
    
    <?php if ($error): ?>
        <p style="color:red;"><?php echo htmlspecialchars($error); ?></p>
    <?php endif; ?>
    
    <?php if ($success): ?>
        <p style="color:green;"><?php echo htmlspecialchars($success); ?></p>
        <p><a href="/login.php">Se connecter maintenant</a></p>
    <?php endif; ?>

    <?php if (!$success): ?>
    <form method="post" action="">
        <label>Nom d'utilisateur: *</label><br>
        <input type="text" name="username" required minlength="3" value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>"><br><br>
        
        <label>Email: *</label><br>
        <input type="email" name="email" required value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>"><br><br>
        
        <label>Biographie (optionnelle):</label><br>
        <textarea name="bio" style="width:100%; height:100px;" placeholder="Parlez-nous un peu de vous..."><?php echo isset($_POST['bio']) ? htmlspecialchars($_POST['bio']) : ''; ?></textarea><br><br>
        
        <label>Mot de passe: *</label><br>
        <input type="password" name="password" required minlength="6"><br><br>
        
        <label>Confirmer le mot de passe: *</label><br>
        <input type="password" name="confirm_password" required minlength="6"><br><br>
        
        <button type="submit" name="register">Créer mon compte</button>
    </form>

    <hr>

    <p>Déjà un compte ? <a href="/login.php">Se connecter</a></p>
    <?php endif; ?>
</body>
</html>