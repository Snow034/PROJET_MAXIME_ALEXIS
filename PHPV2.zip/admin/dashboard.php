<?php
require_once __DIR__ . "/../includes/config.php";
require_once __DIR__ . "/../includes/functions.php";

checkAdmin();

$success = '';
$error = '';

// GESTION DES ARTICLES - AJOUT
if (isset($_POST['add_article'])) {
    $title = isset($_POST['title']) ? trim($_POST['title']) : '';
    $content = isset($_POST['content']) ? trim($_POST['content']) : '';
    $image = null;
    
    if (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
        $image = uploadImage($_FILES['image']);
        if (!$image) {
            $error = "Erreur lors de l'upload de l'image.";
        }
    }
    
    if (empty($title) || empty($content)) {
        $error = "Titre et contenu requis.";
    } elseif (empty($error)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO articles (title, content, image, author_id, created_at) VALUES (?, ?, ?, ?, NOW())");
            $stmt->execute([$title, $content, $image, $_SESSION['user_id']]);
            $success = "Article ajouté avec succès !";
            log_msg("Article créé : $title par " . $_SESSION['username']);
        } catch (PDOException $e) {
            $error = "Erreur lors de l'ajout de l'article.";
            log_msg("Erreur ajout article : " . $e->getMessage());
        }
    }
}

// GESTION DES ARTICLES - MODIFICATION
if (isset($_POST['edit_article'])) {
    $article_id = isset($_POST['article_id']) ? intval($_POST['article_id']) : 0;
    $title = isset($_POST['title']) ? trim($_POST['title']) : '';
    $content = isset($_POST['content']) ? trim($_POST['content']) : '';
    $current_image = isset($_POST['current_image']) ? $_POST['current_image'] : null;
    $image = $current_image;
    
    // Upload nouvelle image si présente
    if (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
        $new_image = uploadImage($_FILES['image']);
        if ($new_image) {
            // Supprimer l'ancienne image si elle existe
            if ($current_image && file_exists(__DIR__ . "/../" . $current_image)) {
                unlink(__DIR__ . "/../" . $current_image);
            }
            $image = $new_image;
        } else {
            $error = "Erreur lors de l'upload de l'image.";
        }
    }
    
    if (empty($title) || empty($content)) {
        $error = "Titre et contenu requis.";
    } elseif (empty($error)) {
        try {
            $stmt = $pdo->prepare("UPDATE articles SET title = ?, content = ?, image = ? WHERE id = ?");
            $stmt->execute([$title, $content, $image, $article_id]);
            $success = "Article modifié avec succès !";
            log_msg("Article '" . $title . "' modifié par " . $_SESSION['username']);
        } catch (PDOException $e) {
            $error = "Erreur lors de la modification de l'article.";
            log_msg("Erreur modification article : " . $e->getMessage());
        }
    }
}

// SUPPRESSION D'ARTICLE
if (isset($_GET['delete_article'])) {
    $article_id = intval($_GET['delete_article']);
    try {
        // Récupérer le titre et l'image avant suppression
        $stmt = $pdo->prepare("SELECT title, image FROM articles WHERE id = ?");
        $stmt->execute([$article_id]);
        $article = $stmt->fetch();
        
        if ($article) {
            // Supprimer l'article
            $stmt = $pdo->prepare("DELETE FROM articles WHERE id = ?");
            $stmt->execute([$article_id]);
            
            // Supprimer l'image physique si elle existe
            if ($article['image'] && file_exists(__DIR__ . "/../" . $article['image'])) {
                unlink(__DIR__ . "/../" . $article['image']);
            }
            
            $success = "Article supprimé avec succès !";
            log_msg("Article '" . $article['title'] . "' supprimé par " . $_SESSION['username']);
        }
    } catch (PDOException $e) {
        $error = "Erreur lors de la suppression.";
        log_msg("Erreur suppression article : " . $e->getMessage());
    }
}

// CHANGEMENT DE RÔLE UTILISATEUR
if (isset($_POST['change_role'])) {
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
    $new_role = isset($_POST['new_role']) ? $_POST['new_role'] : '';
    
    if ($user_id > 0 && in_array($new_role, ['user', 'admin'])) {
        if ($user_id == $_SESSION['user_id'] && $new_role !== 'admin') {
            $error = "Vous ne pouvez pas retirer vos propres droits d'administrateur.";
        } else {
            try {
                $stmt = $pdo->prepare("UPDATE user SET role = ? WHERE id = ?");
                $stmt->execute([$new_role, $user_id]);
                $success = "Rôle modifié avec succès !";
                log_msg("Rôle changé pour user $user_id vers $new_role par " . $_SESSION['username']);
            } catch (PDOException $e) {
                $error = "Erreur lors du changement de rôle.";
                log_msg("Erreur changement rôle : " . $e->getMessage());
            }
        }
    }
}

// RÉCUPÉRER LES ARTICLES
$articles = [];
try {
    $stmt = $pdo->query("SELECT a.*, u.username FROM articles a LEFT JOIN user u ON a.author_id = u.id ORDER BY a.created_at DESC");
    $articles = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = "Erreur lors du chargement des articles.";
    log_msg("Erreur récupération articles : " . $e->getMessage());
}

// Récupérer l'article à modifier si demandé
$edit_article = null;
if (isset($_GET['edit'])) {
    $edit_id = intval($_GET['edit']);
    try {
        $stmt = $pdo->prepare("SELECT * FROM articles WHERE id = ?");
        $stmt->execute([$edit_id]);
        $edit_article = $stmt->fetch();
    } catch (PDOException $e) {
        $error = "Erreur lors du chargement de l'article.";
    }
}

// RÉCUPÉRER LES UTILISATEURS
$users = [];
try {
    $stmt = $pdo->query("SELECT id, username, email, role, created_at FROM user ORDER BY created_at DESC");
    $users = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = "Erreur lors du chargement des utilisateurs.";
    log_msg("Erreur récupération users : " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
</head>
<body>
    <h1>Dashboard Admin - Bienvenue <?php echo htmlspecialchars($_SESSION['username']); ?></h1>
    <a href="/logout.php">Déconnexion</a> | <a href="/index.php">Voir le site</a> | <a href="logs.php">Voir les logs système</a>

    <hr>

    <?php if ($error): ?>
        <p style="color:red;"><?php echo htmlspecialchars($error); ?></p>
    <?php endif; ?>
    
    <?php if ($success): ?>
        <p style="color:green;"><?php echo htmlspecialchars($success); ?></p>
    <?php endif; ?>

    <!-- AJOUTER/MODIFIER UN ARTICLE -->
    <h2><?php echo $edit_article ? 'Modifier l\'article' : 'Ajouter un article'; ?></h2>
    <?php if ($edit_article): ?>
        <p><a href="dashboard.php">← Annuler la modification</a></p>
    <?php endif; ?>
    <form method="post" enctype="multipart/form-data">
        <?php if ($edit_article): ?>
            <input type="hidden" name="article_id" value="<?php echo $edit_article['id']; ?>">
            <input type="hidden" name="current_image" value="<?php echo htmlspecialchars($edit_article['image'] ?? ''); ?>">
        <?php endif; ?>
        
        <label>Titre:</label><br>
        <input type="text" name="title" required style="width:100%;" value="<?php echo $edit_article ? htmlspecialchars($edit_article['title']) : ''; ?>"><br><br>
        
        <label>Contenu:</label><br>
        <textarea name="content" required style="width:100%;height:150px;"><?php echo $edit_article ? htmlspecialchars($edit_article['content']) : ''; ?></textarea><br><br>
        
        <label>Image <?php echo $edit_article ? '(laisser vide pour garder l\'actuelle)' : '(optionnelle)'; ?>:</label><br>
        <?php if ($edit_article && $edit_article['image']): ?>
            <p>Image actuelle: <br><img src="/<?php echo htmlspecialchars($edit_article['image']); ?>" width="150"></p>
        <?php endif; ?>
        <input type="file" name="image" accept="image/*"><br><br>
        
        <button type="submit" name="<?php echo $edit_article ? 'edit_article' : 'add_article'; ?>">
            <?php echo $edit_article ? 'Enregistrer les modifications' : 'Publier l\'article'; ?>
        </button>
    </form>

    <hr>

    <!-- LISTE DES ARTICLES -->
    <h2>Liste des articles (<?php echo count($articles); ?>)</h2>
    <?php if (empty($articles)): ?>
        <p>Aucun article pour le moment.</p>
    <?php else: ?>
        <table border="1" cellpadding="10" style="width:100%; border-collapse:collapse;">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Image</th>
                    <th>Titre</th>
                    <th>Auteur</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($articles as $article): ?>
                    <tr>
                        <td><?php echo $article['id']; ?></td>
                        <td>
                            <?php if ($article['image']): ?>
                                <img src="/<?php echo htmlspecialchars($article['image']); ?>" width="100">
                            <?php else: ?>
                                Pas d'image
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($article['title']); ?></td>
                        <td><?php echo htmlspecialchars($article['username'] ?? 'Inconnu'); ?></td>
                        <td><?php echo date('d/m/Y H:i', strtotime($article['created_at'])); ?></td>
                        <td>
                            <a href="?edit=<?php echo $article['id']; ?>">Modifier</a> | 
                            <a href="?delete_article=<?php echo $article['id']; ?>" 
                               onclick="return confirm('Êtes-vous sûr ?');">
                                Supprimer
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <hr>

    <!-- GESTION DES UTILISATEURS -->
    <h2>Gestion des utilisateurs (<?php echo count($users); ?>)</h2>
    <?php if (empty($users)): ?>
        <p>Aucun utilisateur.</p>
    <?php else: ?>
        <table border="1" cellpadding="10" style="width:100%; border-collapse:collapse;">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Rôle</th>
                    <th>Inscrit le</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?php echo $user['id']; ?></td>
                        <td><?php echo htmlspecialchars($user['username']); ?></td>
                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                        <td><strong><?php echo strtoupper($user['role']); ?></strong></td>
                        <td><?php echo date('d/m/Y', strtotime($user['created_at'])); ?></td>
                        <td>
                            <form method="post" style="display:inline;">
                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                <select name="new_role">
                                    <option value="user" <?php echo $user['role'] === 'user' ? 'selected' : ''; ?>>User</option>
                                    <option value="admin" <?php echo $user['role'] === 'admin' ? 'selected' : ''; ?>>Admin</option>
                                </select>
                                <button type="submit" name="change_role">Modifier</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</body>
</html>