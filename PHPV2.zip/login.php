<?php
require_once __DIR__ . "/includes/config.php";
require_once __DIR__ . "/includes/functions.php";

$error = '';
$success = '';

// CONNEXION
if (isset($_POST['login'])) {
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    
    if (empty($email) || empty($password)) {
        $error = "Email et mot de passe requis.";
    } elseif (!is_valid_email($email)) {
        $error = "Email invalide.";
    } else {
        try {
            $stmt = $pdo->prepare("SELECT * FROM user WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                
                log_msg("Connexion réussie : " . $user['username']);
                
                if ($user['role'] === 'admin') {
                    redirect('/admin/dashboard.php');
                } else {
                    redirect('/index.php');
                }
            } else {
                $error = "Email ou mot de passe incorrect.";
                log_msg("Tentative de connexion échouée pour : $email");
            }
        } catch (PDOException $e) {
            $error = "Erreur de connexion.";
            log_msg("Erreur connexion : " . $e->getMessage());
        }
    }
}

// Si déjà connecté, rediriger
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] === 'admin') {
        redirect('/admin/dashboard.php');
    } else {
        redirect('/index.php');
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
</head>
<body>
    <h1>Connexion</h1>
    
    <p><a href="/index.php">← Retour à l'accueil</a></p>
    
    <?php if ($error): ?>
        <p style="color:red;"><?php echo htmlspecialchars($error); ?></p>
    <?php endif; ?>
    
    <?php if ($success): ?>
        <p style="color:green;"><?php echo htmlspecialchars($success); ?></p>
    <?php endif; ?>

    <form method="post" action="">
        <label>Email:</label><br>
        <input type="email" name="email" required><br><br>
        
        <label>Mot de passe:</label><br>
        <input type="password" name="password" required><br><br>
        
        <button type="submit" name="login">Se connecter</button>
    </form>

    <hr>

    <p>Pas encore de compte ? <a href="/register.php">Créer un compte</a></p>
</body>
</html>