<?php
require_once __DIR__ . "/includes/config.php";
require_once __DIR__ . "/includes/functions.php";

$is_logged_in = isset($_SESSION['user_id']);
$is_admin = $is_logged_in && $_SESSION['role'] === 'admin';

// Récupérer tous les articles
$articles = [];
try {
    $stmt = $pdo->query("SELECT a.*, u.username FROM articles a LEFT JOIN user u ON a.author_id = u.id ORDER BY a.created_at DESC");
    $articles = $stmt->fetchAll();
} catch (PDOException $e) {
    log_msg("Erreur récupération articles page d'accueil : " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accueil - Blog</title>
</head>
<body>
    <h1>Mon Blog</h1>
    
    <?php if ($is_logged_in): ?>
        <p>Bienvenue, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong></p>
        <?php if ($is_admin): ?>
            <a href="/admin/dashboard.php">Dashboard Admin</a> | 
        <?php endif; ?>
        <a href="/logout.php">Déconnexion</a>
    <?php else: ?>
        <p>
            <a href="/login.php">Se connecter</a> | 
            <a href="/register.php">Créer un compte</a>
        </p>
    <?php endif; ?>

    <hr>

    <h2>Articles</h2>
    
    <?php if (empty($articles)): ?>
        <p>Aucun article disponible pour le moment.</p>
    <?php else: ?>
        <?php foreach ($articles as $article): ?>
            <article style="border:1px solid #ddd; padding:15px; margin-bottom:20px;">
                <?php if ($article['image']): ?>
                    <img src="/<?php echo htmlspecialchars($article['image']); ?>" 
                         alt="<?php echo htmlspecialchars($article['title']); ?>" 
                         style="max-width:300px; height:auto;">
                <?php endif; ?>
                
                <h3><?php echo htmlspecialchars($article['title']); ?></h3>
                
                <p>
                    <small>
                        Par <?php echo htmlspecialchars($article['username'] ?? 'Inconnu'); ?> • 
                        <?php echo date('d/m/Y à H:i', strtotime($article['created_at'])); ?>
                    </small>
                </p>
                
                <p><?php echo nl2br(htmlspecialchars($article['content'])); ?></p>
            </article>
        <?php endforeach; ?>
    <?php endif; ?>
</body>
</html>